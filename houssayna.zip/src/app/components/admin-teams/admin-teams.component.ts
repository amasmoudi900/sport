import { TeamService } from './../../services/team.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-teams',
  templateUrl: './admin-teams.component.html',
  styleUrls: ['./admin-teams.component.css']
})
export class AdminTeamsComponent implements OnInit {

  teams: any = [];
  constructor(private teamService:TeamService) { }

  ngOnInit() {
    this.teamService.sendReqToGetAllTeams().subscribe(
      (data)=> {
        this.teams = data.teamsResult;
      }
    );
  }

}
// [
//   { id: 1, name: 'FCB', foundation: 1899, stadium: 'Camp new', country: 'Spain' },
//   { id: 2, name: 'EST', foundation: 1899, stadium: 'Rades', country: 'Tunisia' },
//   { id: 3, name: 'RMD', foundation: 1902, stadium: 'Berna', country: 'Spain' }
// ]