// import express module
const express = require('express');
// import body-parser module
const bodyParser = require('body-parser');
// create express application
const app = express();

// configure Body Parser
// send response with JSON format
app.use(bodyParser.json());
// parse objects sended from FE
app.use(bodyParser.urlencoded({ extended: true }));

// Security configuration
app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
        "Access-Control-Allow-Headers",
        "Origin, Accept, Content-Type, X-Requested-with"
    );
    res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, POST, DELETE, OPTIONS, PATCH, PUT"
    );
    next();
});

// DB configuration
// import mongoose module
const mongoose = require('mongoose');
// connect app to DB
mongoose.connect('mongodb://localhost:27017/sportHavanaDB');
// import match model
const Match = require('./models/match');
// let users = [
//     { id: 1, fName: 'A', lName: 'B', email: 'a@a.a', pwd: 'aaa', avatar: "assets/images/img_1.jpg" },
//     { id: 2, fName: 'C', lName: 'D', email: 'c@c.c', pwd: 'ccc', avatar: "assets/images/img_2.jpg" },
//     { id: 3, fName: 'E', lName: 'F', email: 'e@e.e', pwd: 'eee', avatar: "assets/images/img_3.jpg" },
//     { id: 4, fName: 'G', lName: 'H', email: 'g@g.g', pwd: 'ggg', avatar: "assets/images/img_2.jpg" }
// ];

// let matches = [
//     { id: 1, scoreOne: 1, scoreTwo: 3, teamOne: 'FCB', teamTwo: 'RMD' },
//     { id: 2, scoreOne: 2, scoreTwo: 1, teamOne: 'CA', teamTwo: 'EST' },
//     { id: 3, scoreOne: 0, scoreTwo: 2, teamOne: 'SEV', teamTwo: 'ATM' },
//     { id: 4, scoreOne: 3, scoreTwo: 1, teamOne: 'PSG', teamTwo: 'MON' }
// ];

// let players = [
//     { id: 1, name: 'Messi', nbr: 10, age: 35, poste: 'ATK', note: 9 },
//     { id: 2, name: 'Xavi', nbr: 6, age: 42, poste: 'MID', note: 7 },
//     { id: 3, name: 'Iniesta', nbr: 8, age: 40, poste: 'MID', note: 8 },
//     // { id: 4, name: 'Buffon', nbr: 1, age: 41, poste: 'GK', note: 8 }
// ];

// let articles = [
//     { id: 1, title: 'Title 1', content: 'Content 1', date: '2021-04-16', img: '' },
//     { id: 2, title: 'Title 2', content: 'Content 2', date: '10/01/21', img: '' },
//     { id: 3, title: 'Title 3', content: 'Content 3', date: '10/01/21', img: '' },
//     { id: 4, title: 'Title 4', content: 'Content 4', date: '10/01/21', img: '' }
// ];

// Business Logic: Get ALL matches
app.get("/matches", (req, res) => {
    console.log('Here into business logic of Get ALL matches');
    Match.find((err, docs) => {
        if (err) {
            console.log('error with DB', err);
        } else {
            res.status(200).json({
                result: docs,
                message: 'Here all matches'
            });
        }
    });
});
// Business Logic: Add match object
app.post("/matches", (req, res) => {
    console.log('here into add match', req.body);
    const matchObj = new Match(
        {
            teamOne: req.body.teamOne,
            teamTwo: req.body.teamTwo,
            scoreOne: req.body.scoreOne,
            scoreTwo: req.body.scoreTwo
        }
    );
    matchObj.save((err, result) => {
        console.log('Here result', result);
        if (err) {
            console.log('Here err', err);
        }
        else {
            res.status(200).json({
                message: 'Added with success'
            });
        }
    });
});

// Business logic: Get match by ID
app.get("/matches/:id", (req, res) => {
    console.log('Here into get match by id', req.params.id);
    Match.findOne({ _id: req.params.id }).then(
        (data) => {
            console.log('Here finded Match', data);
            if (data) {
                res.status(200).json({
                    result: data
                })
            }
        }
    );
});

// Business Logic: Edit match
app.put("/matches/:id", (req, res) => {
    console.log('Here into edit match id', req.params.id);
    console.log('Here into edit match body', req.body);
    Match.updateOne({ _id: req.params.id }, req.body).then(
        (data) => {
            console.log('Here data after edit', data);
            res.status(200).json({
                message: 'Edited with success'
            })
        }
    )

});

app.get("/matches/search/:teamOne", (req, res) => {
    console.log('Getted team one', req.params.teamOne);
    Match.find({ teamOne: req.params.teamOne }).then(
        (data)=>{
            console.log(`Here all matches where teamOne== ${req.params.teamOne}`, data);
            if (data) {
                res.status(200).json({
                    findedMatches:data
                })
            }
        }
    )
});
// Business Logic: Delete match by id
app.delete("/matches/:id", (req, res) => {
    console.log('Here into delete by id', req.params.id);
    Match.deleteOne({ _id: req.params.id }).then(
        (data) => {
            console.log('Here data after delete', data);
            res.status(200).json({
                message: 'Deleted with success'
            });
        }
    )
});

// Business Logic: Get ALL Players
app.get("/players", (req, res) => {
    console.log('Here into business logic of Get ALL players');
    // players === DB

    res.status(200).json({
        result: players,
        message: 'Here all players'
    });
});

// Business Logic: Get All teams
app.get("/teams", (req, res) => {
    console.log('Here into get all teams');
    let teams = [
        { id: 1, name: 'FCB', stadium: 'A stadium', country: 'Spain', logo: 'assets/images/logo_1.png', foundation: '1899' },
        { id: 2, name: 'RMD', stadium: 'B stadium', country: 'Spain', logo: 'assets/images/logo_2.png', foundation: '1860' },
        { id: 3, name: 'JUV', stadium: 'C stadium', country: 'Italy', logo: 'assets/images/logo_3.png', foundation: '1902' },
        { id: 4, name: 'LIV', stadium: 'D stadium', country: 'England', logo: 'assets/images/logo_4.png', foundation: '1918' }
    ];
    res.status(200).json({
        teamsResult: teams,
        message: 'Here all teams'
    });
});

// Business Logic: Calculate IMC
app.post("/players/imc", (req, res) => {
    console.log('Here player values', req.body);
    let height = req.body.height;
    let weight = req.body.weight;
    let imc = weight / (height * height * 0.0001);
    console.log('IMC = ', imc);
    let message;
    if (imc <= 18.5) {
        message = "Insuffisance";
    } else if (18.5 < imc <= 24.9) {
        message = "Normal";
    } else if (25 <= imc <= 29.9) {
        message = "Sur poids";
    } else {
        message = "Obésité";
    }
    res.status(200).json({
        message: message,
        imc: imc
    });
});

// Business Logic: Login
app.post("/users/login", (req, res) => {
    console.log('Here into login', req.body);
    let result;
    for (let i = 0; i < users.length; i++) {
        if (users[i].email == req.body.email &&
            users[i].pwd == req.body.pwd) {
            result = users[i];
            break;
        }
    }
    res.status(200).json({
        result: result
    });
});

// Business Logic: Signup
app.post('/users/signup', (req, res) => {
    console.log('Here into signup', req.body);
    users.push(req.body);
    res.status(200).json({
        message: "Added with success"
    });
});



// Business Logic: Get all users
app.get("/users", (req, res) => {
    console.log('here into get all users');
    res.status(200).json({
        result: users,
        message: 'Here all users'
    })
});

// Business Logic: Get user profile
app.get('/users/:id', (req, res) => {
    console.log('Here user information', req.params.id);
    let findedUser = users.find((obj) => {
        return obj.id == req.params.id
    });
    res.status(200).json({
        result: findedUser,
        message: 'Here finded User'
    });
});

// Business Logic: get player by ID
app.get("/players/:id", (req, res) => {
    console.log('Here into get player by id', req.params.id);
    let findePlayer = players.find((obj) => {
        return obj.id == req.params.id
    });
    res.status(200).json({
        result: findePlayer,
        message: 'Here finded Player'
    });
});

// Business Logic: Get all articles
app.get("/articles", (req, res) => {
    console.log('here into get all articles');
    res.status(200).json({
        result: articles,
        message: 'Here all artciles'
    })
});

// Business Logic: Add article
app.post("/articles", (req, res) => {
    console.log('here into add article', req.body);
    articles.push(req.body);
    res.status(200).json({
        message: 'Added with sucess'
    })
});

// Business Logic: get article by ID
app.get("/articles/:id", (req, res) => {
    console.log('Here into get article by id', req.params.id);
    let findedArticle = articles.find((obj) => {
        return obj.id == req.params.id
    });
    res.status(200).json({
        result: findedArticle,
        message: 'Here finded Article'
    });
});

// Business Logic: Edit article
app.put("/articles/:id", (req, res) => {
    console.log('Here into edit article id', req.params.id);
    console.log('Here into edit article body', req.body);
    for (let i = 0; i < articles.length; i++) {
        if (articles[i].id == req.params.id) {
            articles[i] = req.body;
            break;
        }
    }
    res.status(200).json({
        message: 'Edited with success'
    })
});



module.exports = app;